module.exports = {
    root: true,
    extends: ["@protoxyz/custom-library"],
    rules: {
        "@typescript-eslint/no-explicit-any": "off",
    },
};
