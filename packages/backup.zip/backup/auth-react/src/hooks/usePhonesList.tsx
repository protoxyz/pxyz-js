import { ResponseStatus, PaginatedArgs } from '@protoxyz/types';
import { useProtocolAuth } from '../contexts/protocol-context';
import useSWR from 'swr';
import {
  FrontendCreatePhoneNumberOptions,
  FrontendListPhoneNumbers200Response,
  FrontendListPhoneNumbersPath,
} from '@protoxyz/core';
import { useCallback, useState } from 'react';

export function phonesListCacheKey({
  cursor,
  perPage,
  userId,
}: PaginatedArgs & { userId?: string }) {
  return [FrontendListPhoneNumbersPath, userId, cursor, perPage]
    .filter(Boolean)
    .join(':');
}

export const useProtocolAuthPhonesList = ({
  cursor = null,
  perPage = 10,
}: PaginatedArgs) => {
  const { user, protocol, navigate, setState } = useProtocolAuth();
  const [isCreating, setIsCreating] = useState(false);
  const [createError, setCreateError] = useState<string>(null);
  const [deletingId, setDeletingId] = useState<string>(null);
  const [deleteError, setDeleteError] = useState<string>(null);
  const [settingPrimaryId, setSettingPrimaryId] = useState<string>(null);
  const [setPrimaryError, setSetPrimaryError] = useState<string>(null);
  const [preparingVerificationId, setPreparingVerificationId] =
    useState<string>(null);
  const [preparingVerificationError, setPreparingVerificationError] =
    useState<string>(null);
  const [attemptingVerificationId, setAttemptingVerificationId] =
    useState<string>(null);
  const [attemptingVerificationError, setAttemptingVerificationError] =
    useState<string>(null);

  const cacheKey = phonesListCacheKey({
    userId: user?.id,
    cursor,
    perPage,
  });

  const userPhones = user?.phoneNumbers ?? [];

  const { data, error, isLoading, mutate } =
    useSWR<FrontendListPhoneNumbers200Response>(
      cacheKey,
      () =>
        protocol.auth.phoneNumbers.list({
          query: {
            cursor: cursor?.toString(),
            perPage: perPage.toString(),
          },
        }),
      {
        fallbackData: {
          meta: {
            count: userPhones.length,
            next:
              userPhones.length > 0
                ? (userPhones[userPhones.length - 1].createdAt as Date)
                : null,
            numPages: 1,
            perPage: 10,
            total: userPhones.length ?? 0,
          },
          data: userPhones,
          status: ResponseStatus.Success,
        },
      },
    );

  const createPhone = useCallback(
    async ({ phone }: FrontendCreatePhoneNumberOptions['body']) => {
      setIsCreating(true);
      const response = await protocol.auth.phoneNumbers.create({
        body: {
          phone,
        },
      });
      if (response.status === ResponseStatus.Error) {
        // setCreateError(response.error);
      } else {
        mutate();
      }
      setIsCreating(false);
      return response;
    },
    [],
  );

  const setPrimary = useCallback(
    async ({ id }: { id: string }) => {
      setSettingPrimaryId(id);
      const response = await protocol.auth.phoneNumbers.setPrimary({
        path: {
          phoneId: id,
        },
      });
      if (response.status === ResponseStatus.Error) {
        setSetPrimaryError(response.error);
      } else {
        mutate();
        setState((state) => ({
          ...state,
          user: {
            ...state.user,
            primaryPhoneId: id,
          },
        }));
      }
      setSettingPrimaryId(null);
      return response;
    },
    [mutate],
  );

  const sendCode = useCallback(
    async ({ id }: { id: string }) => {
      setPreparingVerificationId(id);
      const response = await protocol.auth.phoneNumbers.prepareVerification({
        path: {
          phoneId: id,
        },
      });
      if (response.status === ResponseStatus.Error) {
        setPreparingVerificationError(response.error);
      } else {
        mutate();
      }
      setPreparingVerificationId(null);
      return response;
    },
    [mutate],
  );

  const verify = useCallback(
    async ({ id, code }: { id: string; code: string }) => {
      setAttemptingVerificationId(id);
      const response = await protocol.auth.phoneNumbers.verify({
        path: {
          phoneId: id,
        },
        body: {
          code,
        },
      });
      if (response.status === ResponseStatus.Error) {
        setAttemptingVerificationError(response.error);
      } else {
        mutate();
      }
      setAttemptingVerificationId(null);
      return response;
    },
    [mutate],
  );

  const deletePhone = useCallback(
    async ({
      id,
      afterDeleteUri,
      onDelete,
    }: {
      id: string;
      afterDeleteUri?: string;
      onDelete?: () => void;
    }) => {
      setDeletingId(id);
      const response = await protocol.auth.phoneNumbers.delete({
        path: {
          phoneId: id,
        },
      });
      if (response.status === ResponseStatus.Success) {
        mutate();
        if (afterDeleteUri) navigate(afterDeleteUri ?? '/');
        onDelete();
      } else {
        setDeleteError(response.error);
      }
      setDeletingId(null);
      return response;
    },
    [],
  );

  return {
    phones: data,
    error,
    isLoading,
    isCreating,
    createPhone,
    createError,
    setCreateError,
    deletePhone,
    deletingId,
    deleteError,

    setPrimary,
    settingPrimaryId,
    setPrimaryError,
    isSettingPrimary: settingPrimaryId !== null,

    sendCode,
    preparingVerificationId,
    preparingVerificationError,
    isPreparingVerification: preparingVerificationId !== null,

    verify,
    attemptingVerificationId,
    attemptingVerificationError,
    isAttemptingVerification: attemptingVerificationId !== null,
  };
};
