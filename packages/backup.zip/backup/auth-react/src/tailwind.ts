const tailwindPaths =
  './node_modules/@protoxyz/auth-react/dist/**/*.{js,ts,jsx,tsx}';

export { tailwindPaths };
