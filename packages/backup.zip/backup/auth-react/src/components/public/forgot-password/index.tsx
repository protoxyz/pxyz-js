import { cn } from '../../../lib/utils';
import { Card } from '../../ui/card';

export function ForgotPassword() {
  return (
    <Card className={cn('w-full border-none shadow-2xl lg:max-w-sm')}></Card>
  );
}
