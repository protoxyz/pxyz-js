module.exports = {
    root: true,
    extends: ["@protoxyz/custom-react"],
    rules: {
        "@typescript-eslint/no-explicit-any": "off",
        "turbo/no-undeclared-env-vars": "off",
    },
};
