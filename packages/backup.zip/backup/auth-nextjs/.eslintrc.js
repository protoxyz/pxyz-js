module.exports = {
    root: true,
    extends: ["@protoxyz/custom-next"],
    rules: {},
};
